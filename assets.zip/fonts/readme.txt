#integration in css file

@font-face {
  font-family: "Bai_Jamjuree";
  src: url("#font-Path");
  font-weight: normal;
  font-style: normal;
}